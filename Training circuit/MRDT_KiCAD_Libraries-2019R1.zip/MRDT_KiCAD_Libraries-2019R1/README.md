# KiCad-Hardware-Libraries
KiCad Schematic symbols and PCB footprints for MissouriMRDT PCB designs
